package eu.siacs.conversations.xmpp.stanzas;

public class PresencePacket extends AbstractStanza {

	public PresencePacket() {
		super("presence");
	}
}
