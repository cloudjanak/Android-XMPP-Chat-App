package eu.siacs.conversations.utils;

import java.util.List;

import android.os.Bundle;

public interface OnPhoneContactsLoadedListener {
	public void onPhoneContactsLoaded(List<Bundle> phoneContacts);
}
